singleDuration = 30;
run("generateSuccessiveClickTrain_RatECoG.m");

singleDuration = 60;
run("generateSuccessiveClickTrain_RatECoG.m");

singleDuration = 125;
run("generateSuccessiveClickTrain_RatECoG.m");

singleDuration = 250;
run("generateSuccessiveClickTrain_RatECoG.m");

singleDuration = 500;
run("generateSuccessiveClickTrain_RatECoG.m");
