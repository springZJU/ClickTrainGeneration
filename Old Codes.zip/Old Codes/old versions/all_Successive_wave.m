singleDuration = 30;
run("generateSuccessiveClickTrain.m");

singleDuration = 60;
run("generateSuccessiveClickTrain.m");

singleDuration = 125;
run("generateSuccessiveClickTrain.m");

singleDuration = 250;
run("generateSuccessiveClickTrain.m");

singleDuration = 500;
run("generateSuccessiveClickTrain.m");
