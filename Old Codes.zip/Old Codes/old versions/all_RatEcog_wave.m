%% S1 Duration
singleDuration = 1000;
run("generateClickTrain_RatECoG.m");
singleDuration = 2000;
run("generateClickTrain_RatECoG.m");
singleDuration = 3000;
run("generateClickTrain_RatECoG.m");
singleDuration = 4000;
run("generateClickTrain_RatECoG.m");
singleDuration = 5000;
run("generateClickTrain_RatECoG.m");

